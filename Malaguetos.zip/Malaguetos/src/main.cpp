/*
 * Description: Main file to create and start the 2D game.
 */
#include "../include/game.h"

int main() {
    Game game;
    return game.run();
}